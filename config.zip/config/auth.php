<?php

    use App\Models\User;
    use App\Models\Admin;

    return [

        'defaults' => [
            'guard' => env('AUTH_GUARD', 'web'),
            'passwords' => env('AUTH_PASSWORD_BROKER', 'users'),
        ],

        'guards' => [
            'web' => [
                'driver' => 'session',
                'provider' => 'users',
            ],

            // حارس لوحة التحكم (الويب) — قائم على الجلسة
            'admin' => [
                'driver' => 'session',
                'provider' => 'admins',
            ],

            // 🟢 حارس واجهة الـAPI للأدمن — قائم على توكن Sanctum (للموبايل/الطلبات عديمة الحالة)
            // لتفعيله بالكامل: اجعل AdminAuthController@login يُصدر توكنًا، ثم غيّر
            // مسارات الأدمن في routes/api.php من auth:admin إلى auth:admin-api
            'admin-api' => [
                'driver' => 'sanctum',
                'provider' => 'admins',
            ],
        ],

        'providers' => [
            'users' => [
                'driver' => 'eloquent',
                'model' => env('AUTH_MODEL', User::class),
            ],

            'admins' => [
                'driver' => 'eloquent',
                'model' => Admin::class,
            ],
        ],

        'passwords' => [
            'users' => [
                'provider' => 'users',
                'table' => env('AUTH_PASSWORD_RESET_TOKEN_TABLE', 'password_reset_tokens'),
                'expire' => 60,
                'throttle' => 60,
            ],

            'admins' => [
                'provider' => 'admins',
                'table' => 'password_reset_tokens',
                'expire' => 60,
                'throttle' => 60,
            ],
        ],

        'password_timeout' => env('AUTH_PASSWORD_TIMEOUT', 10800),

    ];
